docker build \
  --platform linux/amd64 \
  --tag hudalab/epipolicy-server:1 \
  --build-arg CACHEBUST=$(date +%s) .
