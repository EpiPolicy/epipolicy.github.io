cd /epipolicy/manager/files/exports/db_epipolicy
bash import.sh

cd /epipolicy/manager/files/map
python3 import.py

cd /epipolicy/manager/files/exports/db_epipolicy_session
bash import.sh