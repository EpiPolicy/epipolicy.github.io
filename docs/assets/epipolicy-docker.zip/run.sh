docker container run \
  --name=epipolicy-server \
  --platform linux/amd64 \
  -p 8080:80 -p 8000:8000 -p 27018:27017 \
  -d hudalab/epipolicy-server:1