#!/bin/bash

echo "Starting mongod"
mongod --config /etc/mongod.conf &
mongod_pid=$!
echo "mongod started"

echo "Importing data in DB"
bash db-import.sh
echo "Data imported"

echo "Starting UI server"
/usr/sbin/apachectl start
echo "UI server started"

cd epipolicy

echo "Starting Manager server"
python3 -m manager api &
epi_api_pid=$!
echo "Manager started"

echo "Starting Simulator"
cd simulator
python3 pyarmor_main.py &
epi_sim_pid=$!
echo "Simulator started"

# Keep the process alive
while true; do sleep 1; done
