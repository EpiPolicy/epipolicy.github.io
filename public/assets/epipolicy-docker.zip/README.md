# EpiPolicy Docker Server

It is based on ubuntu:20.04
It installs all needed dependencies and imports the packaged EpiPolicy project. 
Furthermore, it runs all needed servers

To build this image:

    ./build.sh

To run this image:

    ./run.sh

EpiPolicy UI is accessible at

    http://localhost:8080

Username: user2
Password: health24#Realize
