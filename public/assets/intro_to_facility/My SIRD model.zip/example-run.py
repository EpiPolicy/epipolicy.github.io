
import pyepipolicy
import matplotlib.pyplot as plt

config = pyepipolicy.Config('localhost')
project = pyepipolicy.Project('My SIRD model_2021-06-02-135144.json')
results = project.run(config)

fig = plt.figure()
ax = plt.axes()
ax.plot(results.compartment("R"))
fig.show()
